package com.example.studyplanner;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DailyPlannerActivity extends AppCompatActivity {

    private EditText editTextDate, editTextTodo, editTextGoals, editTextMood;
    private Button buttonSave;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_planner);

        editTextDate = findViewById(R.id.editTextDate);
        editTextTodo = findViewById(R.id.editTextTodo);
        editTextGoals = findViewById(R.id.editTextGoals);
        editTextMood = findViewById(R.id.editTextMood);
        buttonSave = findViewById(R.id.buttonSave);
        databaseHelper = new DatabaseHelper(this);

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = editTextDate.getText().toString();
                String todo = editTextTodo.getText().toString();
                String goals = editTextGoals.getText().toString();
                String mood = editTextMood.getText().toString();

                databaseHelper.insertDailyPlan(date, todo, goals, mood);
                Toast.makeText(DailyPlannerActivity.this, "Daily plan saved!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
