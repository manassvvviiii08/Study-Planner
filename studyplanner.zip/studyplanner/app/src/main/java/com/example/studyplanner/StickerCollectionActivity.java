package com.example.studyplanner;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class StickerCollectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sticker_collection);
        // Implement your sticker collection logic here
    }
}
