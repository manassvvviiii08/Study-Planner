package com.example.studyplanner;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private Button buttonDailyPlanner, buttonMonthlyPlanner, buttonWeeklyPlanner, buttonPomodoro, buttonProgress, buttonStickerCollection, buttonTimetable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        buttonDailyPlanner = findViewById(R.id.buttonDailyPlanner);
        buttonMonthlyPlanner = findViewById(R.id.buttonMonthlyPlanner);
        buttonWeeklyPlanner = findViewById(R.id.buttonWeeklyPlanner);
        buttonPomodoro = findViewById(R.id.buttonPomodoro);
        buttonProgress = findViewById(R.id.buttonProgress);
        buttonStickerCollection = findViewById(R.id.buttonStickerCollection);
        buttonTimetable = findViewById(R.id.buttonTimetable);

        buttonDailyPlanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, DailyPlannerActivity.class));
            }
        });

        buttonMonthlyPlanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, MonthlyPlannerActivity.class));
            }
        });

        buttonWeeklyPlanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, WeeklyPlannerActivity.class));
            }
        });

        buttonPomodoro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, PomodoroActivity.class));
            }
        });



        buttonStickerCollection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, StickerCollectionActivity.class));
            }
        });

        buttonTimetable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, TimetableActivity.class));
            }
        });
    }
}
