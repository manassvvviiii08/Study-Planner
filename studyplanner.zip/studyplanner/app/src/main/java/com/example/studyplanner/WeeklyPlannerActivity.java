package com.example.studyplanner;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class WeeklyPlannerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weekly_planner);
        // Implement your weekly planner logic here
    }
}
